function y = ProportionalFit(beta, x)
y = beta*x;