/***************************************************
This is the header file for the Grabber code.  Include this
in your files.

This code was intended to be used inside of a matlab interface,
but can be used as a generic grabber class for anyone who needs
one.

Written by Micah Richert.
07/14/2005
**************************************************/

#if defined(_DEBUG) && defined(_MSC_VER)
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#define new new(_NORMAL_BLOCK,__FILE__,__LINE__)
#endif

#include "dshow.h"
#include "qedit.h"
#include <assert.h>

template<class T> class vector
{
	public:
		vector()
		{
			datavec = NULL;
			datavecSize = 0;
			nr = 0;
			datavecSize = resize(128);
		}

		~vector()
		{
			free(datavec);
		}

		T at(unsigned int i)
		{
			if (i >= nr) return NULL;
			return datavec[i];
		}

		int size()
		{
			return nr;
		}

		void assign(unsigned int i, T data)
		{
			if (i >= nr) return;
			datavec[i] = data;
		}

		void add(T data)
		{
			nr++;
			if (nr > datavecSize)
			{
				datavecSize = resize(datavecSize*2);
				if (nr > datavecSize)
				{
					//we've failed, but can't return an error here...
					nr--;
					return;
				}
			}
			datavec[nr-1] = data;
		}

		void clear()
		{
			nr = 0;
			datavecSize = resize(128);
		}

	private:
		T* datavec;
		unsigned int nr;
		unsigned int datavecSize;

		int resize(int newsize)
		{
			void* tmp = realloc(datavec,newsize*sizeof(T));
			if (tmp)
			{
				datavec = (T*)tmp;
				return newsize;
			}
			return datavecSize;
		}
};

// since the Audio and Video CB vectors are public we need to make the CB interface public too
class CSampleGrabberCB : public ISampleGrabberCB
{
public:
	CSampleGrabberCB();
	virtual ~CSampleGrabberCB();

	vector<BYTE*> frames;
	vector<int> frameBytes;
	vector<int> frameNrs;
	vector<double> frameTimes;

	// use this to get data format information, ie. bit depth, sampling rate...
	BYTE *pbFormat;
	GUID subtype; // what is the encoding

	unsigned int frameNr;
	bool disabled;
	bool done;
	bool isAudio;

	int bytesPerWORD;
	double rate;
	double startTime, stopTime;

	// Fake out any COM ref counting
	//
	STDMETHODIMP_(ULONG) AddRef() { return 2; }
	STDMETHODIMP_(ULONG) Release() { return 1; }

	// Fake out any COM QI'ing
	//
	STDMETHODIMP QueryInterface(REFIID riid, void ** ppv);

	// We don't implement this one
	//
	STDMETHODIMP SampleCB( double SampleTime, IMediaSample * pSample ){ return 0; }

	// The sample grabber is calling us back on its deliver thread.
	// This is NOT the main app thread!
	//
	STDMETHODIMP BufferCB( double dblSampleTime, BYTE * pBuffer, long lBufferSize );
};

// this is the main grabber class.  I think the interfaces and names are fairly self explanatory
class DDGrabber
{
public:
	vector<CSampleGrabberCB*> VideoCBs;
	vector<CSampleGrabberCB*> AudioCBs;
	DDGrabber();

	HRESULT buildGraph(char* filename);
	HRESULT doCapture();
	HRESULT getVideoInfo(unsigned int id, int* width, int* height, double* rate, int* nrFramesCaptured, int* nrFramesTotal, double* totalDuration);
	HRESULT getAudioInfo(unsigned int id, int* nrChannels, double* rate, int* bits, int* nrFramesCaptured, int* nrFramesTotal, GUID* subtype, double* totalDuration);
	void getCaptureInfo(int* nrVideo, int* nrAudio);
	// data must be freed by caller
	HRESULT getVideoFrame(unsigned int id, int frameNr, BYTE** data, int* nrBytes, double* time);
	// data must be freed by caller
	HRESULT getAudioFrame(unsigned int id, int frameNr, BYTE** data, int* nrBytes, double* time);
	void setFrames(int* frameNrs, int nrFrames);
	void setTime(double startTime, double stopTime);
	void setTrySeeking(int tryseek);
	void disableVideo();
	void disableAudio();
	void cleanUp(); // must be called at the end, in order to render anything afterward.

#ifdef MATLAB_MEX_FILE
	void setMatlabCommand(char * matlabCommand);
	void runMatlabCommand();
#endif
private:
	IGraphBuilder* pGraphBuilder;
	bool stopForced;
    bool tryseeking;
	vector<int> frameNrs;
    double startTime, stopTime;

#ifdef MATLAB_MEX_FILE
	vector<int> lastFrames;
	char* matlabCommand;
#endif

	void MyFreeMediaType(AM_MEDIA_TYPE& mt);
	PIN_INFO getPinInfo(IPin* pin);
	IPin* getInputPin(IBaseFilter* filt);
	IPin* getOutputPin(IBaseFilter* filt);
	bool isRenderer(IBaseFilter* filt);
	IPin* connectedToInput(IBaseFilter* filt);
	GUID getMajorType(IBaseFilter* filt);
	HRESULT insertCapture(IGraphBuilder* pGraphBuilder, IBaseFilter* pRenderer, AM_MEDIA_TYPE* mt, CSampleGrabberCB** grabberCB);
	HRESULT insertVideoCapture(IGraphBuilder* pGraphBuilder, IBaseFilter* pRenderer);
	HRESULT insertAudioCapture(IGraphBuilder* pGraphBuilder, IBaseFilter* pRenderer);
	HRESULT changeToNull(IGraphBuilder* pGraphBuilder, IBaseFilter* pRenderer);
	HRESULT mangleGraph(IGraphBuilder* pGraphBuilder);
};