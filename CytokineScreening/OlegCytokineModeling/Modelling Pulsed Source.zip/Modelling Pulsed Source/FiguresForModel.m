addpath('/Users/Oleg/Documents/MATLAB/FlOleg Project');
addpath('/Users/Oleg/Documents/MATLAB/General Utilities');

cd '/Users/oleg/Documents/Derivations/Cytokine Distribution 1D'
set(0, 'DefaultAxesFontSize', 14)

%% assume 5 min secretion at high rate 10*12 molec per second. Then nothing for 55 min
EC50 = 10; %in pM
R = 5; % cell radius in um
secretion_rate = 120; %molecules per sec
D = 100; % diffusion coeff um^2/s

J = secretion_rate/(4*pi*R*D)*1e15/6e23/(EC50*1e-12);
L = 1000; %simulation space length in cell radia
x = linspace(1, L, 10000); %in cell radia
t1 = [1 10 60 60*(2:5)]; %time points in sec for presentation
t1ave = 30*(1:10); %time points in sec for averaging (every 30s)
%J = 1/600;

S1secr = TimeDependent3D_Cytokine_DiffusionOnly(t1*D/R^2, x, J)%to unitless time
S1ave = TimeDependent3D_Cytokine_DiffusionOnly(t1ave*D/R^2, x, J)%for averaging

Cstationary = J./S1secr.profiles.r*EC50; 

subplot(2, 2, 1)
plotColor('semilogy', S1secr.profiles.r/2, S1secr.profiles.C*EC50); %convert x-scale to diameters

figure(gcf)
maxC = EC50*max(S1secr.profiles.C(:));
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)
set(gca, 'YLim', [maxC/100 maxC], 'FontSize', 12);
v = axis;
%hold on;
%h = semilogy(S.profiles.r/2, Cstationary(:), '-k');
%set(h, 'LineWidth', 2);
%hold off;
legend({'t = 1 s', 't = 10 s', 't = 1 min', 't = 2 min', ...
    't = 3 min',  't = 4 min',...
     't = 5 min'})
title('Profiles')
ylabel('concentration (pM)', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
axis(v);
text(5, 6, 'A', 'FontSize', 16)

subplot(2, 2, 2)
% normalize G to unity
G = S1secr.CF.G./repmat(max(S1secr.CF.G), size(S1secr.CF.G, 1), 1);
plotColor('semilogy', S1secr.CF.r/2, G); %convert x-scale to diameters
figure(gcf)
set(gca, 'YLim', [1/100 1], 'FontSize', 12);
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)
Rstationary = J./S1secr.profiles.r;
title('Correlations')
ylabel('G', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
text(90, 0.5, 'B', 'FontSize', 16)


%% now assume 55 min of no secretion
t2 = [1 10 60 300*(1:11)]; %time points in sec for presentation
t2ave = 30*(1:110); %time points in sec for averaging (every 30s)
%J = 1/600;

S2secr = TimeDependent3D_Cytokine_DiffusionOnly(t2*D/R^2, x, 0, 'Initial Conditions', S1secr.profiles.C(:, end))%to unitless time
S2ave = TimeDependent3D_Cytokine_DiffusionOnly(t2ave*D/R^2, x, 0, 'Initial Conditions', S1secr.profiles.C(:, end))%for averaging

subplot(2, 2, 3)
plotColor('semilogy', S2secr.profiles.r/2, EC50*S2secr.profiles.C(:, [1:4 6:2:14])); %convert x-scale to diameters
figure(gcf)
maxC = EC50*max(S2secr.profiles.C(:));
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)
set(gca, 'YLim', [maxC/1e5 maxC], 'FontSize', 12);
%set(gca, 'FontSize', 12);

legend({'t = 1 s', 't = 10 s', 't = 1 min', 't = 5 min', ...
    't = 15 min', 't = 25 min',...
    't = 35 min', 't = 45 min', ...
    't = 55 min'})
title('Profiles')
ylabel('concentration (pM)', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
text(50, 7, 'C', 'FontSize', 16);

subplot(2, 2, 4)
% normalize G to unity
G = S2secr.CF.G(:, [1:4 6:2:14])./repmat(max(S2secr.CF.G(:, [1:4 6:2:14])), size(S2secr.CF.G(:, [1:4 6:2:14]), 1), 1);
plotColor('semilogy', S2secr.CF.r/2, G); %convert x-scale to diameters
figure(gcf)
set(gca, 'YLim', [1/100 1], 'FontSize', 12);
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)

title('Correlations')
ylabel('G', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
text(350, 0.5, 'D', 'FontSize', 16)

%% averaging

%combine
Scomb = S1ave;
Scomb.profiles.t = [Scomb.profiles.t, Scomb.profiles.t(end)+S2ave.profiles.t];
Scomb.profiles.C = [Scomb.profiles.C, S2ave.profiles.C];
Scomb.profiles.response = [Scomb.profiles.response, S2ave.profiles.response];
Scomb.CF.G = [Scomb.CF.G, S2ave.CF.G];
Scomb.CF.Gresponse = [Scomb.CF.Gresponse, S2ave.CF.Gresponse];

for i = 1:(size(Scomb.profiles.response, 2)/20),
    Scomb.profiles.responseAve(:, i) = mean(Scomb.profiles.response(:, (20*(i-1)+1):(20*i)), 2);
    % calculate correlations
    x = Scomb.profiles.r;
    
    %for zero-padding for Fourier transform
    minx = min(x);
    dx = median(diff(x));
    xpad = ((dx/2):dx:minx)';
    ypad = zeros(size(xpad));
    Y.r = [xpad; Scomb.profiles.r];
    Y.fr = [ypad; Scomb.profiles.responseAve(:, i)];
    FY = FourierTransform(Y, '3D');
    FYsq.r = FY.q;
    FYsq.fr = abs(FY.fq).^2;
    CF = FourierTransform(FYsq, '3D');
        %S.CF.r = CF.q;
    Scomb.CF.GresponseAve(:, i) = CF.fq;
end

%% Fig1: plot everything for short pulses
subplot(3, 2, 1)
%concentration during pulse
plotColor('semilogy', S1secr.profiles.r/2, S1secr.profiles.C*EC50); %convert x-scale to diameters

figure(gcf)
maxC = EC50*max(S1secr.profiles.C(:));
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)
set(gca, 'YLim', [maxC/100 maxC], 'FontSize', 12);
v = axis;
%hold on;
%h = semilogy(S.profiles.r/2, Cstationary(:), '-k');
%set(h, 'LineWidth', 2);
%hold off;
legend({'t = 1 s', 't = 10 s', 't = 1 min', 't = 2 min', ...
    't = 3 min',  't = 4 min',...
     't = 5 min'})
title('Concentration profiles during cytokine pulse')
ylabel('concentration (pM)', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
axis(v);
text(5, 15, 'A', 'FontSize', 16)



subplot(3, 2, 2)
% concentration correlations during pulse
% normalize G to unity
G = S1secr.CF.G./repmat(max(S1secr.CF.G), size(S1secr.CF.G, 1), 1);
plotColor('semilogy', S1secr.CF.r/2, G); %convert x-scale to diameters
figure(gcf)
set(gca, 'YLim', [1/100 1], 'FontSize', 12);
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)
Rstationary = J./S1secr.profiles.r;
title('Concentration correlations during the pulse')
ylabel('G', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
text(70, 0.5, 'B', 'FontSize', 16)


subplot(3, 2, 3)
%concentrations during swithc off
plotColor('semilogy', S2secr.profiles.r/2, EC50*S2secr.profiles.C(:, [1:4 5 9 14])); %convert x-scale to diameters
figure(gcf)
maxC = EC50*max(S2secr.profiles.C(:));
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)
set(gca, 'YLim', [maxC/1e5 maxC], 'FontSize', 12);
%set(gca, 'FontSize', 12);

legend({'t = 1 s', 't = 10 s', 't = 1 min', 't = 5 min', ...
    't = 10 min', 't = 30 min',...
    't = 55 min'})
title('Concentration profiles after the pulse')
ylabel('concentration (pM)', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
text(50, 5, 'C', 'FontSize', 16);

subplot(3, 2, 4)
%concentration correlations during switch off
% normalize G to unity
G = S2secr.CF.G(:, [1:4 6:2:14])./repmat(max(S2secr.CF.G(:, [1:4 6:2:14])), size(S2secr.CF.G(:, [1:4 6:2:14]), 1), 1);
plotColor('semilogy', S2secr.CF.r/2, G); %convert x-scale to diameters
figure(gcf)
set(gca, 'YLim', [1/100 1], 'FontSize', 12);
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)

title('Concentration correlation after the pulse')
ylabel('G', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
text(330, 0.5, 'D', 'FontSize', 16)


subplot(3, 2, 5);
%averaged response
plotColor('semilogy', Scomb.profiles.r/2, Scomb.profiles.responseAve); %convert x-scale to diameters
figure(gcf)
maxC = max(Scomb.profiles.responseAve(:));
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)
set(gca, 'YLim', [maxC/1e4 maxC], 'FontSize', 12, 'YTick', [1e-3 1e-1]);
%v = axis;
Rstationary = J./(J+S.profiles.r);
%hold on;
%h = semilogy(S.profiles.r/2, Rstationary, '-k');
%set(h, 'LineWidth', 2);
%axis(v);
%hold off;
legend({'t = 10 min', 't = 20 min', 't = 30 min', 't = 40 min', ...
    't = 50 min', 't = 60 min'})

title('Response Profiles')
ylabel('response', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
text(30, 0.1, 'E', 'FontSize', 16)

subplot(3, 2, 6)
% normalize G to unity
G = Scomb.CF.GresponseAve./repmat(max(Scomb.CF.GresponseAve), size(Scomb.CF.GresponseAve, 1), 1);
plotColor('semilogy', Scomb.CF.r/2, G); %convert x-scale to diameters
figure(gcf)
set(gca, 'YLim', [1/100 1], 'FontSize', 12);
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)

title('Response Correlations')
ylabel('G response', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
text(330, 0.5, 'F', 'FontSize', 16)


%% now to oscillating source
% assume 5 min secretion at  rate 10*2 molec per second. Then nothing for 5
% min and then repeated switches on and off

EC50 = 10; %in pM
R = 5; % cell radius in um
secretion_rate = 20; %molecules per sec
D = 100; % diffusion coeff um^2/s

J = secretion_rate/(4*pi*R*D)*1e15/6e23/(EC50*1e-12);
L = 1000; %simulation space length in cell radia
x = linspace(1, L, 10000); %in cell radia
%t1 = [1 10 60 60*(2:5)]; %time points in sec for presentation
t1ave = 30*(1:10); %time points in sec for averaging (every 30s)
%J = 1/600;



%t2 = [1 10 60 300*(1:11)]; %time points in sec for presentation
%t2ave = 30*(1:110); %time points in sec for averaging (every 30s)
%J = 1/600;

t2ave = t1ave;

S1ave = TimeDependent3D_Cytokine_DiffusionOnly(t1ave*D/R^2, x, J)%for averaging
S2ave = TimeDependent3D_Cytokine_DiffusionOnly(t2ave*D/R^2, x, 0, 'Initial Conditions', S1ave.profiles.C(:, end))%for averaging
Cstationary = J./S1secr.profiles.r*EC50; 

Scomb = S1ave;
Scomb.profiles.t = [Scomb.profiles.t, Scomb.profiles.t(end)+S2ave.profiles.t];
Scomb.profiles.C = [Scomb.profiles.C, S2ave.profiles.C];
Scomb.profiles.response = [Scomb.profiles.response, S2ave.profiles.response];
Scomb.CF.G = [Scomb.CF.G, S2ave.CF.G];
Scomb.CF.Gresponse = [Scomb.CF.Gresponse, S2ave.CF.Gresponse];

% repeat 5 times
for i=1:5,
    i
    S1ave = TimeDependent3D_Cytokine_DiffusionOnly(t1ave*D/R^2, x, J, 'Initial Conditions', Scomb.profiles.C(:, end))%for averaging
    S2ave = TimeDependent3D_Cytokine_DiffusionOnly(t2ave*D/R^2, x, 0, 'Initial Conditions', S1ave.profiles.C(:, end))%for averaging
    Cstationary = J./S1secr.profiles.r*EC50; 
    
    Scomb.profiles.t = [Scomb.profiles.t, Scomb.profiles.t(end)+S1ave.profiles.t];
    Scomb.profiles.C = [Scomb.profiles.C, S1ave.profiles.C];
    Scomb.profiles.response = [Scomb.profiles.response, S1ave.profiles.response];
    Scomb.CF.G = [Scomb.CF.G, S1ave.CF.G];
    Scomb.CF.Gresponse = [Scomb.CF.Gresponse, S1ave.CF.Gresponse];

    
    Scomb.profiles.t = [Scomb.profiles.t, Scomb.profiles.t(end)+S2ave.profiles.t];
    Scomb.profiles.C = [Scomb.profiles.C, S2ave.profiles.C];
    Scomb.profiles.response = [Scomb.profiles.response, S2ave.profiles.response];
    Scomb.CF.G = [Scomb.CF.G, S2ave.CF.G];
    Scomb.CF.Gresponse = [Scomb.CF.Gresponse, S2ave.CF.Gresponse];
end;

%% averaging
for i = 1:(size(Scomb.profiles.response, 2)/20),
    Scomb.profiles.C_Ave(:, i) = mean(Scomb.profiles.C(:, (20*(i-1)+1):(20*i)), 2);
    Scomb.profiles.responseAve(:, i) = mean(Scomb.profiles.response(:, (20*(i-1)+1):(20*i)), 2);
    % calculate correlations
    x = Scomb.profiles.r;
    
    %for zero-padding for Fourier transform
    minx = min(x);
    dx = median(diff(x));
    xpad = ((dx/2):dx:minx)';
    ypad = zeros(size(xpad));
    Y.r = [xpad; Scomb.profiles.r];
    Y.fr = [ypad; Scomb.profiles.responseAve(:, i)];
    FY = FourierTransform(Y, '3D');
    FYsq.r = FY.q;
    FYsq.fr = abs(FY.fq).^2;
    CF = FourierTransform(FYsq, '3D');
        %S.CF.r = CF.q;
    Scomb.CF.GresponseAve(:, i) = CF.fq;
    
    Y.r = [xpad; S.profiles.r];
    Y.fr = [ypad; Scomb.profiles.C_Ave(:, i)];
    FY = FourierTransform(Y, '3D');
    FYsq.r = FY.q;
    FYsq.fr = abs(FY.fq).^2;
    CF = FourierTransform(FYsq, '3D');
        %S.CF.r = CF.q;
    Scomb.CF.G_Ave(:, i) = CF.fq;

end

%% Fig. 2
subplot(2, 2, 1)
%concentration during pulse
plotColor('semilogy', Scomb.profiles.r/2, Scomb.profiles.C_Ave*EC50); %convert x-scale to diameters

figure(gcf)
maxC = EC50*max(Scomb.profiles.C_Ave(:));
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)
set(gca, 'YLim', [maxC/100 maxC], 'FontSize', 12);
v = axis;
%hold on;
%Cstationary = (J/2)./S1secr.profiles.r*EC50; 
%h = semilogy(S.profiles.r/2, Cstationary(:), '-k');
%set(h, 'LineWidth', 2);
%hold off;
legend({'t = 10 min', 't = 20 min', 't = 30 min', 't = 40 min', ...
    't = 50 min', 't = 60 min'})
title('Concentration profiles periodic source')
ylabel('concentration (pM)', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
axis(v);
text(5, 15, 'A', 'FontSize', 16)



subplot(2, 2, 2)
% concentration correlations during pulse
% normalize G to unity
G = Scomb.CF.G_Ave./repmat(max(Scomb.CF.G_Ave), size(Scomb.CF.G_Ave, 1), 1);
plotColor('semilogy', Scomb.CF.r/2, G); %convert x-scale to diameters
figure(gcf)
set(gca, 'YLim', [1/100 1], 'FontSize', 12, 'XLim', [0 250]);
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)
Rstationary = J./Scomb.profiles.r;
title('Concentration correlations')
ylabel('G', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
text(70, 0.5, 'B', 'FontSize', 16)


subplot(2, 2, 3);
%averaged response
plotColor('semilogy', Scomb.profiles.r/2, Scomb.profiles.responseAve); %convert x-scale to diameters
figure(gcf)
maxC = max(Scomb.profiles.responseAve(:));
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)
set(gca, 'YLim', [maxC/1e4 maxC], 'FontSize', 12, 'YTick', [1e-3 1e-1]);
%v = axis;
Rstationary = J./(J+S.profiles.r);
%hold on;
%h = semilogy(S.profiles.r/2, Rstationary, '-k');
%set(h, 'LineWidth', 2);
%axis(v);
%hold off;
legend({'t = 10 min', 't = 20 min', 't = 30 min', 't = 40 min', ...
    't = 50 min', 't = 60 min'})

title('Response Profiles')
ylabel('response', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
text(30, 0.1, 'E', 'FontSize', 16)

subplot(2, 2, 4)
% normalize G to unity
G = Scomb.CF.GresponseAve./repmat(max(Scomb.CF.GresponseAve), size(Scomb.CF.GresponseAve, 1), 1);
plotColor('semilogy', Scomb.CF.r/2, G); %convert x-scale to diameters
figure(gcf)
set(gca, 'YLim', [1/100 1], 'FontSize', 12, 'XLim', [0 250]);
%text(4, 90, ['L = ' num2str(L)], 'FontSize', 14)

title('Response Correlations')
ylabel('G response', 'FontSize', 14)
xlabel('r (cell dia)', 'FontSize', 14)
text(330, 0.5, 'F', 'FontSize', 16)

